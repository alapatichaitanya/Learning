package com.store.service;

import java.util.Scanner;

import com.store.model.Book;
import com.store.model.Library;

public class LibraryService {

	Library lib = new Library();
	Scanner sc = new Scanner(System.in);

	public void doService() {

		boolean ok = true, librarian = false, borrower = false;
		Book b1 = new Book("Maths", "author1", "20210519", 28);
		Book b2 = new Book("Science", "author2", "20210721", 53);
		Book b3 = new Book("History", "author3", "20220410", 45);
		Book b4 = new Book("English", "author4", "20190219", 39);
		Book b5 = new Book("Computers", "author5", "20210810", 24);
		Book[] books = { b1, b2, b3, b4, b5 };
		lib.setBooks(books);
		while (ok) {
			sc = new Scanner(System.in);
			System.out.println("Please select the login type Librarian=1 /Borrrower=2");
			int opt = sc.nextInt();

			if (opt == 1) {
				sc = new Scanner(System.in);
				System.out.println("Please enter Librarian username ");
				String s = sc.nextLine();
				if ("sai".equalsIgnoreCase(s)) {
					sc = new Scanner(System.in);
					System.out.println("Please enter Librarian password ");
					s = sc.nextLine();
					if ("saip".equalsIgnoreCase(s)) {
						librarian = true;
					} else {
						notValidPwd();
					}

				} else {
					notValidUser();
				}

			} else {
				sc = new Scanner(System.in);
				System.out.println("Please enter Borrrower username ");
				if ("krish".equalsIgnoreCase(sc.nextLine())) {
					sc = new Scanner(System.in);
					System.out.println("Please enter Borrrower password ");
					if ("krishp".equalsIgnoreCase(sc.nextLine())) {
						borrower = true;
					} else {
						notValidPwd();
					}
				} else {
					notValidUser();
				}
			}
			if (librarian) {
				doLibrarianService();
				librarian = false;
			}
			if (borrower) {
				doBorrowerService();
				borrower = false;
			}
			sc = new Scanner(System.in);
			System.out.println("If you want to continue, Please enter 1");
			if (sc.nextInt() != 1)
				ok = false;
		}
		System.out.println("-----THANK YOU-------------");
	}

	private void notValidUser() {
		System.out.println("It is not valid username, So exiting");
		System.exit(1);
	}

	private void notValidPwd() {
		System.out.println("It is not valid password, So exiting");
		System.exit(1);
	}

	private void doLibrarianService() {
		boolean isPresent = false;
		sc = new Scanner(System.in);
		System.out.println("Please enter Book name to view ");
		String name = sc.nextLine();
		for (Book book : lib.getBooks()) {
			if (name.equalsIgnoreCase(book.getName())) {
				System.out.println("Book " + book.getName() + " count is " + book.getCount());
				isPresent = true;
			}
		}
		if (!isPresent) {
			System.out.println("Book " + name + " not present in Library ");
		}
	}

	private void doBorrowerService() {
		boolean isPresent = false;
		sc = new Scanner(System.in);
		System.out.println("Please enter Book to return[0]/ take[1], eg : Bookname 0");
		String input = sc.nextLine();
		String[] array = input.split(" ");
		String name = array[0];
		boolean take = array[1].equalsIgnoreCase("1") ? true : false;
		for (Book book : lib.getBooks()) {
			if (name.equalsIgnoreCase(book.getName())) {
				isPresent = true;
				if (take) {
					System.out.println("You can take the book " + book.getName());
				} else {
					System.out.println("Book " + book.getName() + " has been succesfully returned.");
				}
			}
		}
		if (!isPresent) {
			System.out.println("Book " + name + " not present in Library ");
		}
	}
}