package com.store.service;

public class LibraryInventory {

	public static void main(String[] args) {

		LibraryService service = new LibraryService();
		service.doService();
	}
}